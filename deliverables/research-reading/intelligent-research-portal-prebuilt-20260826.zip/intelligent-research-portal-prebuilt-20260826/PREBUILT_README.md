# 智能科研预构建包

这是 2026-08-26 从同批源码执行 `pnpm build` 生成的静态产物，只用于快速预览或部署验证，不能替代开发源码包。

请通过静态服务器访问，不建议直接双击 `index.html`：

```bash
npx serve .
```

正式开发、嵌合或重新发布时，请使用对应的 `intelligent-research-portal-source-20260826.zip`，执行锁文件安装和完整检查后再构建。
